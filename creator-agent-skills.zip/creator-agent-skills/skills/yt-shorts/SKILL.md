---
name: yt-shorts
description: Find Shorts hiding inside a long video transcript and write a new first line for each. Use whenever the user shares a transcript, SRT or script and wants Shorts, Reels or clips cut from it.
---

# yt-shorts

1. Take the transcript (with timecodes if available). Ask for it if missing.
2. Find 3-5 segments of 20-45 seconds that make sense WITHOUT the rest of the video: one idea, a clear start, a payoff.
3. For each: start-end timecode, why it works (one line), a NEW first line written to hook cold viewers (don't reuse the original sentence if it needs context), and the on-screen caption.
4. Flag segments that need context and say what to trim.

Never invent timecodes. If the transcript has none, quote the opening words of the segment instead.

End with: "Ship it, or change it?"
