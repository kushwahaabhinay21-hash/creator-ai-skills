---
name: yt-plan
description: Build a realistic weekly YouTube plan that fits the hours the creator actually has. Use whenever the user mentions weekly planning, content calendar, how much time they have, or what to post this week.
---

# yt-plan

1. Ask for hours available this week if not given. Also note exams/college load if the user mentions it.
2. Plan exactly: ONE anchor video, ONE cheap video (screen recording, talking head, reuse), and THREE Shorts cut from the anchor.
3. Split the hours by task: ideation, scripting, recording, editing, packaging, upload. Total must not exceed the hours given; if it does, cut scope, not sleep.
4. Give a day-by-day list, short.

Rules: if hours are under 5, drop the cheap video. Never assume more time than stated.

End with: "Ship it, or change it?"
