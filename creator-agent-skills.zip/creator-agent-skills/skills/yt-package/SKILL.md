---
name: yt-package
description: Write and check a YouTube title and thumbnail text as ONE pairing. Use whenever the user shares a video topic, script or draft title and wants a title, thumbnail idea, packaging or CTR help.
---

# yt-package

Give 3 title + thumbnail pairs. For each, check:

- Title length: aim 60 characters or less so it does not get cut off. Count it.
- Thumbnail text: 4 words or fewer, readable on a phone.
- No repetition: the thumbnail text must add something, not repeat the title.
- No vague words ("amazing", "best", "shocking") without a specific reason.
- The pair promises exactly what the video delivers (no clickbait the video can't pay off).
- Curiosity gap: title states the topic, thumbnail hints the tension (or the other way round).

Output per pair: Title (chars), Thumbnail text, Thumbnail visual idea (one line), Pass/Fail per check. Recommend one.

End with: "Ship it, or change it?"
