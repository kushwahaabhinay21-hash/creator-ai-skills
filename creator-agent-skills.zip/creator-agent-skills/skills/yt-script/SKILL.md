---
name: yt-script
description: Turn one video idea into a spoken YouTube script with 5 scored hook options and retention beats. Use whenever the user shares a video idea, topic or title and wants a script, hook, intro or "what should I say", even if they do not say "script". Works in Hindi, Hinglish or English.
---

# yt-script

1. Read `~/.claude/youtube/voice.md`. If it is missing, ask for 3 transcripts or 5-10 lines of how the creator talks. Match that language and tone.
2. If the idea is vague, ask ONE question (who is it for?). Otherwise proceed.
3. Write 5 hooks, each using a different formula: Statistic, Mistake ("galti jo sab karte hain"), Before/After, Question, Story-in-one-line, Contrarian ("log kehte hain X, sach ye hai"), Challenge, Secret.
4. Score each hook 1-5 on: clarity (clear in 3 seconds), curiosity (open loop), specificity (concrete, not vague), relevance to the viewer, speakability (easy to say aloud). Show total /25. This is a rough checklist, not a prediction.
5. Pick the best 2. Explain in one line why.
6. Write the script for the best hook: Hook (0-15 s), Promise, Body in 3-5 beats, Payoff, one clear CTA. Mark `[ON SCREEN]` notes and a re-hook line every ~60 seconds.
7. Estimate runtime at 150 words per minute (slower for Hindi: ~130).

Rules: never invent numbers, results or claims. If a figure is needed, ask the creator or write the line without it. Write for speaking: short sentences.

End with: "Ship it, or change it?" and the script in one copyable block.
